/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package input.data.reservasi.hotel;

/**
 *
 * @author Ardy Sendleep
 */
public class ProgramReservasiHotel {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Frame_program_reservasi_hotel Laund = new Frame_program_reservasi_hotel();
        Laund.setVisible(true);
    }
}
