gambar.1

* @author User
*/
import javax.swing.JOptiinPane;
piblic class SELAMAT DATANG {


	/**
	 * @param args the command line arguments
	 */
	 public static void main(String[] args) {
		// TODO code APPLICATION LOGIC HERE
			JOptionPane.showMessageDialog
 (null,"Selamat Datang Di HOTEL BINTANG10");
		new UTS ().setVisible(true);
		}
		
	}
	
	
gambar.2

//TODO add your handling code here:
for (int q=101; 1<=103; qtt) {
KODE.additem("A"+q);
}
for 